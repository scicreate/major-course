using System;
using System.Collections;
using System.Drawing;
namespace GATest
{
    /// <summary>
    /// �򵥵��Ŵ��㷨ʵ��
    /// ������
    /// little_lucky@163.com
    /// 2007-12
    /// 2009-5�޸�
    /// </summary>
    class GeneticAlgorithm
    {
        private const double PI = 3.1415926535897932384;
        private double m_a, m_b;//��������a��b
        private double m_minValueX;//x���䷶Χ����С
        private double m_maxValueX;//x���ֵ
        private double m_length;//���䳤��
        private int m_codingLength;//���볤��
        private int m_populationNumber;//��Ⱥ��С
        private string[][] m_populations;//��Ⱥ
        private double[] m_doublePopulation;
        private double[] m_fitness;//��Ӧ������
        private double m_crossRate;//�������
        private double m_varRate;//�������
        private double m_winFitness;//��ʤ��Ӧ��ֵ��y���ֵ��
        private float m_minY, m_maxY;//�������������Сyֵ����ͼ��
        private int m_zeroY;//�������ᣬ��ͼ��

        public int ZeroY
        {
            get { return m_zeroY; }
            set { m_zeroY = value; }
        }
        private PointF[] m_DrawPoints;//�������ߵ�

        public PointF[] DrawPoints
        {
            get { return m_DrawPoints; }
            set { m_DrawPoints = value; }
        }
        public double WinFitness
        {
            get { return m_winFitness; }
            set { m_winFitness = value; }
        }
        private string[] m_winCoding;
        public string[] WinCoding
        {
            get { return m_winCoding; }
            set { m_winCoding = value; }
        }
        private double m_winValue;
        public double WinValue
        {
            get { return m_winValue; }
            set { m_winValue = value; }
        }
        /// <summary>
        /// ���캯��
        /// </summary>
        /// <param name="min">����ȡֵ��Χ-��Сֵ</param>
        /// <param name="max">����ȡֵ��Χ-���</param>
        /// <param name="crossRate">�������</param>
        /// <param name="varRate">�������</param>
        /// <param name="precision">���ȣ�6��ʾС�����6λ</param>
        /// <param name="populationNumber">��Ⱥ��С</param>
        /// <param name="picWidth">��ͼ�Ŀ���</param>
        /// <param name="picHeight">��ͼ�߶�</param>
        public GeneticAlgorithm(double min, double max, double a, double b, double crossRate, double varRate, int precision, int populationNumber, int picWidth, int picHeight)
        {
            m_maxValueX = max;
            m_minValueX = min;
            m_a = a;
            m_b = b;
            m_crossRate = crossRate;
            m_varRate = varRate;
            m_populationNumber = populationNumber;
            m_length = max - min;
            m_populations = new string[m_populationNumber][];
            m_doublePopulation = new double[m_populationNumber];
            m_fitness = new double[m_populationNumber];
            m_codingLength = GetCodingLength(min, max, precision);//ȡ�ñ��볤��
            InitDrawPoints(picWidth, picHeight);
            InitPopulation();
        }
        /// <summary>
        /// ����
        /// </summary>
        /// <param name="width">�������</param>
        /// <param name="height">����߶�</param>
        private void InitDrawPoints(int width, int height)
        {
            m_minY = float.MaxValue;
            m_maxY = float.MinValue;
            int pointNumber = width;//Ҫ�����ٵ㣬ȡ�����ͼ����
            double length = (m_maxValueX - m_minValueX) / (double)pointNumber;//ÿ��Զ��һ����
            double x = m_minValueX;
            double y = 0.0d;
            m_DrawPoints = new PointF[pointNumber];
            for (int i = 0; i < pointNumber; i++)
            {
                m_DrawPoints[i].X = (float)i;
                y = m_a * x * Math.Sin(10.0 * PI * x) + m_b;
                if (y > m_maxY) m_maxY = (float)y;
                else if (y < m_minY) m_minY = (float)y;

                m_DrawPoints[i].Y = (float)y;
                //m_DrawPoints[i].Y = (float)height - (float)68.0 * (float)y;
                x += length;
            }
            float yRange = m_maxY - m_minY;
            if (m_maxY >= 0 && m_minY <= 0)
                m_zeroY = (int)(m_maxY * (float)height / (float)yRange);
            else if (m_maxY < 0) m_zeroY = -1;
            else if (m_minY > 0) m_zeroY = height + 1;
            

            for (int i = 0; i < pointNumber; i++)
            {
                m_DrawPoints[i].Y = (float)height - (m_DrawPoints[i].Y - m_minY) * (float)height / yRange;
            }
        }
        /// <summary>
        /// �����Ŵ�����
        /// </summary>
        public void DoEvaluation()
        {
            ConvertIndivadual2Double();
            ComputeFitness();
            ComputeWins();
            Selection();
            Crossing();
            Mutation();
        }
        /// <summary>
        /// ������Ӧ�ȼ����ʤ
        /// </summary>
        private void ComputeWins()
        {
            int[] indexs = new int[m_populationNumber];
            for (int i = 0; i < m_populationNumber; i++)
            {
                indexs[i] = i;
            }
            int winIndex = GetMaxIndex(indexs);
            m_winCoding = m_populations[winIndex];
            m_winValue = m_doublePopulation[winIndex];
            m_winFitness = m_fitness[winIndex];
        }
        public int IndivadualNumber()
        {
            Hashtable tmpHash = new Hashtable();
            foreach (double i in m_fitness)
            {
                if (!tmpHash.Contains(i)) tmpHash.Add(i, i);
            }
            return tmpHash.Count;
        }
        /// <summary>
        /// ������Ӧ��
        /// </summary>
        private void ComputeFitness()
        {
            for (int i = 0; i < m_populationNumber; i++)
            {
                double x = m_doublePopulation[i];
                m_fitness[i] = m_a * x * Math.Sin(10.0 * PI * x) + m_b;
            }
        }
        /// <summary>
        /// ѡ�񣬽�����ѡ��
        /// </summary>
        private void Selection()
        {
            int size = 3;//������ģ
            string[][] tmpPopulation = new string[m_populationNumber][];
            for (int i = 0; i < m_populationNumber; i++)
            {
                int[] inSelection = GetRandomIntArray(0, m_populationNumber - 1, size, i);
                int winIndex = GetMaxIndex(inSelection);
                string[] tmpStr = new string[m_codingLength];
                for (int j = 0; j < m_codingLength; j++)
                {
                    tmpStr[j] = m_populations[winIndex][j];
                }
                tmpPopulation[i] = tmpStr;
            }
            m_populations = tmpPopulation;
        }
        /// <summary>
        /// ����
        /// </summary>
        private void Crossing()
        {
            int[] crossRate = GetRandomIntArray(0, 1000, m_populationNumber, 3);
            for (int i = 0; i < m_populationNumber; i++)
            {
                if (crossRate[i] <= m_crossRate * 1000)
                {
                    int[] twoCrossIndex = GetRandomIntArray(0, m_populationNumber - 1, 2, 2);
                    Random rnd = new Random();
                    int crossPlace = rnd.Next(m_codingLength);
                    string[] tmpStr = new string[m_codingLength];
                    for (int j = 0; j < crossPlace; j++)
                    {
                        tmpStr[j] = m_populations[i][j];
                    }
                    for (int j = crossPlace; j < m_codingLength; j++)
                    {
                        tmpStr[j] = m_populations[twoCrossIndex[0]][j];
                    }
                    m_populations[i] = tmpStr;
                }
            }
        }
        /// <summary>
        /// ����
        /// </summary>
        private void Mutation()
        {
            int[] varRate = GetRandomIntArray(0, 1000, m_populationNumber, 3);
            for (int i = 0; i < m_populationNumber; i++)
            {
                Random rand = new Random(i * i);
                int varPlace = rand.Next(m_codingLength);
                if (varRate[i] <= m_varRate * 1000)
                {
                    if (m_populations[i][varPlace] == "0")
                    {
                        m_populations[i][varPlace] = "1";
                    }
                    else
                    {
                        m_populations[i][varPlace] = "0";
                    }
                }
            }
        }
        private int GetMaxIndex(int[] tmp)
        {
            int index = -1;
            double tmpDou = double.MinValue;
            for (int i = 0; i < tmp.Length; i++)
            {
                if (m_fitness[tmp[i]] > tmpDou)
                {
                    tmpDou = m_fitness[tmp[i]];
                    index = tmp[i];
                }
            }
            return index;
        }
        private void ConvertIndivadual2Double()
        {
            for (int i = 0; i < m_populationNumber; i++)
            {
                m_doublePopulation[i] = Coding2Double(m_populations[i]);
            }
        }
        /// <summary>
        /// ��ʼ����Ⱥ
        /// </summary>
        private void InitPopulation()
        {
            for (int i = 0; i < m_populationNumber; i++)
            {
                m_populations[i] = GetRandomBinaryArray(m_codingLength, i);
            }
        }
        /// <summary>
        /// ȡ����Ҫ�ı��볤��
        /// </summary>
        /// <param name="min">��������</param>
        /// <param name="max">��������</param>
        /// <param name="precision">����</param>
        /// <returns>���ر��볤��</returns>
        private int GetCodingLength(double min, double max, int precision)
        {
            int tmpInt = Convert.ToInt32(m_length * Math.Pow(10, precision));
            return Convert.ToString(tmpInt, 2).Length;
        }
        /// <summary>
        /// ����ת��Ϊ��������֮�ڵ�ʵ��ֵ
        /// </summary>
        /// <param name="coding">����</param>
        /// <returns>ʵ��</returns>
        private double Coding2Double(string[] coding)
        {
            double tmp = 0.0d;
            tmp = m_minValueX + (double)Coding2Int(coding) * m_length / (Math.Pow(2, m_codingLength) - 1);
            return tmp;
        }

        /// <summary>
        /// ������ת��Ϊ����
        /// </summary>
        /// <param name="coding">����</param>
        /// <returns>����</returns>
        private int Coding2Int(string[] coding)
        {
            int tmp = 0;
            for (int i = 0; i < coding.Length; i++)
            {
                tmp += int.Parse(coding[i]) * Convert.ToInt32(Math.Pow(2, i));
            }
            return tmp;
        }
        /// <summary>
        /// ���������01����
        /// </summary>
        /// <param name="count"></param>
        /// <param name="ii"></param>
        /// <returns></returns>
        public static string[] GetRandomBinaryArray(int count, int ii)
        {
            Random rnd = new Random(DateTime.Now.Millisecond + ii);
            byte[] keys = new byte[count];
            rnd.NextBytes(keys);
            string[] items = new string[count];
            for (int i = 0; i < count; i++)
            {
                if (keys[i] > 127)
                {
                    items[i] = "1";
                }
                else
                {
                    items[i] = "0";
                }
            }
            return items;
        }
        /// <summary>
        /// ȡ��һ����������飬�ο������ϴ���
        /// �ͳ���˼·��ͬ�����ǲ�ȡ�Ȼ�ȡһ��������ٲ��������ظ�֮�����������
        /// ����������Random.NextBytes �����õ�һ��������ֽ����飬Ȼ������ Array.Sort 
        /// �����ط��������������ֽ����齫˳��Դ��������Ϊ������� Copy ���������
        /// ����ֻ����һ��ѭ����Ϊ˳��Դ���鸳��ֵ��ֻʹ���˼��������Ͷ�û���ü��ϻ�
        /// ���ͼ����࣬����Random.NextBytes ����һ�λ��һ���������������ѭ���ж��
        /// ���ã�����Array.Copy �������ƽ������������ܵõ��Ż���
        /// </summary>
        /// <param name="minValue">��Сֵ</param>
        /// <param name="maxValue">���ֵ</param>
        /// <param name="count">�������Ŀ</param>
        /// <returns>���������</returns>
        public static int[] GetRandomIntArray(int minValue, int maxValue, int count, int ii)
        {
            Random rnd = new Random(DateTime.Now.Millisecond + ii);
            int length = maxValue - minValue + 1;
            byte[] keys = new byte[length];
            rnd.NextBytes(keys);
            int[] items = new int[length];
            for (int i = 0; i < length; i++)
            {
                items[i] = i + minValue;
            }
            Array.Sort(keys, items);
            int[] result = new int[count];
            Array.Copy(items, result, count);
            return result;
        }
    }
}
