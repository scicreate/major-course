using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//using Xml;

namespace GATest
{
    public partial class FormMain : Form
    {
        private PointF[] m_drawPoints;
        private double m_xVal;
        private int m_zeroY;
        private int m_zeroX;
        Graphics m_g;
        private int m_picWidth, m_picHeight;

        public FormMain()
        {
            InitializeComponent();
            ChangeSize();
            m_g = Graphics.FromHwnd(pictureBoxShow.Handle);
        }
        private void ChangeSize()
        {
            m_picHeight = pictureBoxShow.ClientSize.Height;
            m_picWidth = pictureBoxShow.ClientSize.Width;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            richTextBoxStat.Clear();
            m_drawPoints = null;
            pictureBoxShow.Refresh();
            m_g.Flush();
            double xmin = double.Parse(textBoxMinX.Text);
            double xmax = double.Parse(textBoxMaxX.Text);
            GeneticAlgorithm gaTest = new GeneticAlgorithm(xmin, xmax, double.Parse(textBoxA.Text), double.Parse(textBoxB.Text), double.Parse(textBoxCrossRate.Text), double.Parse(textBoxVarRate.Text), 6, int.Parse(textBoxPopulationNum.Text), m_picWidth, m_picHeight);
            m_zeroX = Convert.ToInt32(Math.Abs(xmin) * m_picWidth / (xmax - xmin));
            int i = 10;
            int interations = 0;
            double x, y;
            do
            {
                gaTest.DoEvaluation();
                x = Math.Round(gaTest.WinValue, 6);
                y = Math.Round(gaTest.WinFitness, 6);
                string coding = GetCoding(gaTest.WinCoding);
                this.richTextBoxStat.AppendText(string.Format("\r\n����{0}��,����:{3},����x={1},y={2}", interations + 1, x, y, coding));
                if (interations % 99 == 0) this.richTextBoxStat.ScrollToCaret();
                i = gaTest.IndivadualNumber();
                interations++;
            } while (i > 1 && interations < int.Parse(textBoxIterMax.Text));
            this.richTextBoxStat.ScrollToCaret();
            m_drawPoints = gaTest.DrawPoints;
            m_zeroY = gaTest.ZeroY;
            m_xVal = (x - double.Parse(textBoxMinX.Text)) * m_picWidth / (double.Parse(textBoxMaxX.Text) - double.Parse(textBoxMinX.Text));//ʵֵxת��Ϊ��ͼ��Ļx
            DrawLines();
            GC.Collect();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            DrawLines();
        }
        private string GetCoding(string[] tmp)
        {
            StringBuilder stb = new StringBuilder();
            for (int i = tmp.Length - 1; i >= 0; i--)
            {
                stb.Append(tmp[i]);
            }
            return stb.ToString();
        }
        private void DrawLines()
        {
            if (m_drawPoints != null && m_xVal > 0)
            {
                m_g = Graphics.FromHwnd(pictureBoxShow.Handle);
                pictureBoxShow.Refresh();
                PointF[] points = m_drawPoints;
                double x = m_xVal;
                //���ƺ�������
                Pen myPen = new Pen(Color.Green, 1.0f);
                m_g.DrawLines(myPen, points);
                PointF[] valLine = new PointF[2];
                //x = (x + 1.0) * pictureBoxShow.Width / 3.0;
                x = m_xVal;
                valLine[0].X = (float)x;
                valLine[0].Y = 0;
                valLine[1].X = (float)x;
                valLine[1].Y = (float)m_picHeight;
                //���ƽ��
                myPen.Color = Color.Red;
                myPen.Width = 2.0f;
                m_g.DrawLine(myPen, valLine[0], valLine[1]);
                //����������
                myPen.Color = Color.Yellow;
                myPen.Width = 2.0f;
                m_g.DrawLine(myPen, new Point(m_zeroX + 1, 0), new Point(m_zeroX + 1, m_picHeight));
                m_g.DrawString("x=0", new Font("Tahoma", 15, FontStyle.Bold), new SolidBrush(Color.White), m_zeroX + 10, 20);
                if (m_zeroY >= 0 && m_zeroY <= m_picHeight)
                {
                    m_g.DrawLine(myPen, new Point(0, m_zeroY - 1), new Point(m_picWidth, m_zeroY - 1));
                    m_g.DrawString("y=0", new Font("Tahoma", 15, FontStyle.Bold), new SolidBrush(Color.White), m_zeroX + 10, m_zeroY - 40);
                }
                else if (m_zeroY < 0)
                {
                    m_g.DrawString("������������y<0", new Font("Tahoma", 15, FontStyle.Bold), new SolidBrush(Color.White), m_zeroX + 10, m_picHeight - 40);
                }
                else
                {
                    m_g.DrawString("������������y>0", new Font("Tahoma", 15, FontStyle.Bold), new SolidBrush(Color.White), m_zeroX + 10, m_picHeight - 40);
                }

                m_g.Flush();
            }
        }

        private void FormMain_SizeChanged(object sender, EventArgs e)
        {
            ChangeSize();
        }

        private void FormMain_ResizeEnd(object sender, EventArgs e)
        {
            ChangeSize();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
           // m_picHeight = pictureBoxShow.ClientSize.Height; XmlBuilder.bind();
            m_picWidth = pictureBoxShow.ClientSize.Width;
        }
    }
}