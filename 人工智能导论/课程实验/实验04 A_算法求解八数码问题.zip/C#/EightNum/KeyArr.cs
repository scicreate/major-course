﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EightNum
{
    public class KeyArr
    {
        public KeyArr(byte[,] k)
        {
            this.k = k;
        }
        public byte[,] k;
    }
}
