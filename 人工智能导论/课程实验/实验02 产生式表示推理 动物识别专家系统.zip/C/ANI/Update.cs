﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ANI
{
    public partial class Update : Form
    {

        private string data_path = Environment.CurrentDirectory + "\\rule.txt";

        

        public Update()
        {
            Console.WriteLine(data_path);
            InitializeComponent();
            textBox_update.Text = FileUtil.read_data(data_path);
                   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileUtil.save_update(data_path, textBox_update.Text);
            this.Close();

        }

        private void textBox_update_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
