﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ANI
{
    class FileUtil
    {
        //读取文件
        public static string read_data(string data_path)
        {
            string text = null;
            //【1】创建文件流
            FileStream fs = new FileStream(data_path, FileMode.Open);
            //【2】创建读取器
            StreamReader sr = new StreamReader(fs, Encoding.Default);
            //【3】以流的方式读取数据
            text = sr.ReadToEnd();
            //【4】关闭读取器
            sr.Close();
            //【5】关闭文件流
            fs.Close();
            return text;
        }
        //写入文件
        public static void save_update(string data_path, string text)
        {
            FileStream fs = new FileStream(data_path, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs, Encoding.Default);
            sw.Write(text.Trim());
            sw.Close();
            fs.Close();
        }

    }
}
