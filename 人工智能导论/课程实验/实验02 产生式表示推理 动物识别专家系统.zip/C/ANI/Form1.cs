﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ANI
{

    public partial class Form1 : Form
    {

        private string data_path = Environment.CurrentDirectory + "\\rule.txt"; 

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var input_features = textBox_features.Text.Split(Environment.NewLine.ToCharArray());
            reasoning(input_features.ToList<string>(), parse_text(FileUtil.read_data(data_path))); 

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Update formUpdate = new Update();
            formUpdate.Show(); 

        }

        //解析知识库 
        private Dictionary<RowFact, string> parse_text(string text)
        {
            var array_facts = text.Split(Environment.NewLine.ToCharArray());
            var dic_result = new Dictionary<RowFact, string>();
            for (int i = 0; i < array_facts.Length; i++)
            {
                var fact_items = array_facts[i].Split(" ".ToCharArray());
                var row_fact_list = new List<string>();
                for (int j = 0; j < fact_items.Length; j++)
                {
                    if (j == fact_items.Length - 1)
                    {
                        var row_fact = new RowFact(row_fact_list);
                        dic_result.Add(row_fact, fact_items[j]);
                    }
                    else
                    {
                        row_fact_list.Add(fact_items[j]);
                    }
                }
            }
            return dic_result;
        }

        //推理过程 
        private void reasoning(List<string> features, Dictionary<RowFact, string> dict)
        {
            foreach (KeyValuePair<RowFact, string> pair in dict)
            {
                if (list_contains_list(pair.Key.getLs(), features))
                {
                    foreach (var item in pair.Key.getLs())
                        if (features.Contains(item))
                        {
                            features.Remove(item);
                            textBox_process.AppendText(item + "->");
                        }
                    if (!features.Contains(pair.Value))
                    {
                        features.Add(pair.Value);
                        textBox_process.AppendText(pair.Value);
                        textBox_process.AppendText("\n");
                    }
                }
            }
            var temp_item = features[features.Count - 1];
            foreach (var item in dict.Values)
            {
                if (item == temp_item)
                {
                    label_result.Text = item;
                    return;
                }
            }
            label_result.Text = "推理不出来";
        }

        //规则库中的一行规则的特征是否满足输入的特征中的几条 
        private bool list_contains_list(List<string> list1, List<string> list2)
        {
            bool is_contains = true;
            if (list1.Count > list2.Count)
            {
                foreach (var item in list2)
                {
                    if (!list1.Contains(item))
                    {
                        is_contains = false;
                        return is_contains;
                    }
                }
            }
            else
            {
                foreach (var item in list1)
                {
                    if (!list2.Contains(item))
                    {
                        is_contains = false;
                        return is_contains;
                    }
                }
            }
            return is_contains;
        }

        private void textBox_features_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_process_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }




    //一行事实bean类
    class RowFact
    {
        private List<string> ls = null;
        public RowFact(List<string> ls)
        {
            this.ls = ls;
        }
        public void setLs(List<string> ls)
        {
            this.ls = ls;
        }
        public List<string> getLs()
        {
            return this.ls;
        }
    } 
}
