﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TEST3
{
    public partial class Form1 : Form
    {
        int L1, L2, L3;

        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                L1 = Convert.ToInt32(textBox1.Text);
                L2 = Convert.ToInt32(textBox2.Text);
                L3 = Convert.ToInt32(textBox3.Text);

                label5.Text = (L1+L2+L3).ToString();
            }
            catch
            {
                label5.Text = "输入有误,请输入整数";
            }
          
            
                
        }
    }
}
