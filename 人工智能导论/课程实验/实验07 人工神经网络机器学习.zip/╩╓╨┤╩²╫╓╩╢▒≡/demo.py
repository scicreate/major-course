import numpy as np     
from os import listdir 
from sklearn.neural_network import MLPClassifier 

#将加载的32*32图片矩阵展开成一列向量
def img2vector(fileName):    
    retMat = np.zeros([1024],int) #定义返回的矩阵，大小为1*1024
    fr = open(fileName)           #打开包含32*32大小的数字文件 
    lines = fr.readlines()       
    for i in range(32):           
        for j in range(32):       #并将01数字存放在retMat中     
            retMat[i*32+j] = lines[i][j]    
    return retMat

#加载训练数据的方法
def readDataSet(path):    
    fileList = listdir(path)   
    numFiles = len(fileList)   
    dataSet = np.zeros([numFiles,1024],int) #用于存放所有的数字文件
    hwLabels = np.zeros([numFiles,10])      #用于存放对应的one-hot标签
    for i in range(numFiles):   
        filePath = fileList[i]  #获取文件名称/路径      
        digit = int(filePath.split('_')[0])  #通过文件名获取标签      
        hwLabels[i][digit] = 1.0        #将对应的one-hot标签置1
        dataSet[i] = img2vector(path +'/'+filePath)   
    return dataSet,hwLabels
 
#加载训练集
train_dataSet, train_hwLabels = readDataSet('trainingDigits')

#构建神经网络
clf = MLPClassifier(hidden_layer_sizes=(200,),
                    activation='logistic', solver='adam',
                    learning_rate_init = 0.0001, max_iter=1500)
print(clf)

#训练神经网络
clf.fit(train_dataSet,train_hwLabels)
 
#加载测试集
dataSet,hwLabels = readDataSet('testDigits')

res = clf.predict(dataSet)   #使用训练好的MLP对测试集进行预测
error_num = 0                #统计预测错误的数目
num = len(dataSet)           #测试集的数目
for i in range(num):         #遍历预测结果
    #比较长度为10的数组，返回包含01的数组，0为不同，1为相同
    #若预测结果与真实结果相同，则10个数字全为1，否则不全为1
    if np.sum(res[i] == hwLabels[i]) < 10: 
        error_num += 1                     
print("Total num:",num," Wrong num:", \
	error_num,"  WrongRate:",error_num / float(num))
